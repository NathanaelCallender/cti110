Pat = input()
print('Hello Pat and welcome to CS Online!')
June = input()
print('Hello June and welcome to CS Online!')